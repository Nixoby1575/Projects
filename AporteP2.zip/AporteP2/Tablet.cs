using System;
namespace Aporte2
{
    public class Tablet : Advices
    {
        public Tablet(int IMEI, string Brand, string Model, string OperativeSystem, string Manufacturing, string FunctionAvc_1, string FuctionAvc_2, string FuctionAvc_3) : base(IMEI, Brand, Model, OperativeSystem, Manufacturing, FunctionAvc_1, FuctionAvc_2, FuctionAvc_3) { }

        public override void Print()
        {
            Console.WriteLine("**************************************");
            Console.WriteLine("Dispositivo a reparar:");
            Console.WriteLine("**************************************");
            Console.WriteLine("marca: {0}", Brand);
            Console.WriteLine("modelo: {0}", Model);
            Console.WriteLine("imei: {0}", IMEI);
            Console.WriteLine("sistema operativo: {0}", OperativeSystem);
            Console.WriteLine("**************************************");
        }

        public override void FunctionsAvc()
        {
            Console.WriteLine("***************************");
            Console.WriteLine("Funcionalidades del dispositivo: ");
            Console.WriteLine("1.  {1}", FunctionAvc_1);
            Console.WriteLine("2. {1}", FuctionAvc_2);
            Console.WriteLine("3. {1}", FuctionAvc_3);
        }

        public void ContainsChip()
        {
            Console.WriteLine("Tiene Chip: si");
        }
    }
}
