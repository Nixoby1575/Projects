﻿using System;

namespace Aporte2{
    public class Program{
        /*public static void Main(String []arg){

            Cell movil = new Cell(00000,"huawei", "y221", "android", "japon","cargador","pantalla", "reproductor de musica", "camara de fotos");
            Tablet tablet = new Tablet(05648420,"Samsung", "y221", "android", "japon","cargador","pantalla", "reproductor de musica", "camara de fotos");
            Client cliente = new Client("Mario Guerrero", "Tablet", "camara");
            Client cliente_2 = new Client("Mario Guerrero", "Tablet", "pantalla");
            
            List<Cliente> lista3 = new List<Cliente>();
            lista3.Add(cliente);
            lista3.Add(cliente2);

            foreach(Cliente lista4 in lista3){
                lista4.ordenReparacion();
            }

            List<Dispositivos> lista1 = new List<Dispositivos>();
            lista1.Add(celular);
            lista1.Add(tablet);

            foreach(Dispositivos lista2 in lista1){
                lista2.imprimir();
                lista2.funcionalidades();
            }

            foreach(Ichip lista5 in lista1){
                lista5.mostrarChip();
            }*/




    public static void Main(String[] args){


            var AdviceMobile1 = new Advice1();
            Cell Advice1 = new Cell(5215125,"Samsung", "y221", "android", "Korea","pantalla", "reproductor de musica", "camara de fotos");
            Client cliente = new Client("Alondra Ruvalcaba", "Tablet", "Camara");
            List<Client> lista3 = new List<Client>();
            lista3.Add(cliente);
            foreach(Client lista4 in lista3){
            lista4.RepairOrder();
            var reparacion = new DamageWater(AdviceMobile1);
            Console.WriteLine("{0}",reparacion.Repair());
            }
            List<Advices> lista1 = new List<Advices>();
            lista1.Add(Advice1);
            foreach(Advices lista2 in lista1){
                lista2.Print();
                lista2.FunctionsAvc();
            }

            var repair2 = new DamageHit(AdviceMobile1);
            Console.WriteLine("{0}",repair2.Repair());

            var repair3 = new HardwareRepair(AdviceMobile1);
            Console.WriteLine("{0}",repair3.Repair());

            var PowerBankAdd = new Hearphones(AdviceMobile1);
            Console.WriteLine("{0}",PowerBankAdd.AddAdvice());

    }
}
}