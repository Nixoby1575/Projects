using System;

namespace Aporte2
{
    public abstract class Advices{
        public int IMEI{get; set;}
        public string Brand{get; set;}
        public string Model{get; set;}
        public string OperativeSystem{get; set;}
        public string Manufacturing{get; set;}
        public String FunctionAvc_1{get; set;}
        public string FuctionAvc_2{get; set;}
        public string FuctionAvc_3{get; set;}

        public Advices(int IMEI, string Brand, string Model, string OperativeSystem, string Manufacturing, string FunctionAvc_1, string FuctionAvc_2, string FuctionAvc_3){
        this.IMEI = IMEI;
        this.Brand = Brand;
        this.Model = Model;
        this.OperativeSystem = OperativeSystem;
        this.Manufacturing = Manufacturing;
        this.FunctionAvc_1 = FunctionAvc_1;
        this.FuctionAvc_2 = FuctionAvc_2;
        this.FuctionAvc_3 = FuctionAvc_3;
        }

        public abstract void Print();
        public abstract void FunctionsAvc();


    }
            
}