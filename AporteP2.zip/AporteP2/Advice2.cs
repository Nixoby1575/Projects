using System;

namespace Aporte2
{
    public class Advice2: BaseAdvice
    {
    public override string Repair(){

    var rptAdvice = "Se ha reparado su dispositivo";
    return rptAdvice;

    }
   public override string AddAdvice(){

    var rptAdvice = "Desea agregar una adición?";
    return rptAdvice;
    }
}
}