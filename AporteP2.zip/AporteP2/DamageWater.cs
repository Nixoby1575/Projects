
namespace Aporte2
{
    public class DamageWater: Decorator{

    public DamageWater(BaseAdvice baseAdvice):base(baseAdvice){

    }
    
    public override string Repair()
    
    {
        var repairing = "Daño seleccionado daño de dispositivo por agua";
          return repairing;

    }

    
}

}
