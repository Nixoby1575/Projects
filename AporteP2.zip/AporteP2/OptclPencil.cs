using System;

namespace Aporte2 {
public class OptclPencil : Decorator
{
    public OptclPencil(BaseAdvice order) : base(order)
    {
        
    }

    public override string AddAdvice()
    {
        Console.WriteLine("Ha agregado Lapiz óptico");
        var Adiccion = base.AddAdvice();
        
        return Adiccion;
    }
}
}