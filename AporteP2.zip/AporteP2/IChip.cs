using System;

namespace Aporte2{
    interface IChip
    {
        void ContainsChip();
    }
}