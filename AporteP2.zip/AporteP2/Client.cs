using System;

namespace Aporte2{
    class Client{
        public string Client_Name{get; set;}
        public string Advice{get; set;}
        public string function{get; set;}
        
        public Client(string Client_Name, string Advice, string function){
            this.Client_Name = Client_Name;
            this.Advice = Advice;
            this.function = function;
        }

        public void RepairOrder(){
            Console.WriteLine("Nombre del cliente: {0} ", Client_Name);
            Console.WriteLine("Disposirtivo: {0}", Advice);
            Console.WriteLine("Funcionalidad de dispositivo a reparar{0}", function);
        }
    }
}