using System;

namespace Aporte2 {
public abstract class BaseAdvice{
    
    public abstract string AddAdvice();
    public abstract string Repair();

    }
    
}
