using System;

namespace Aporte2 {
public class PowerBank : Decorator
{
    public PowerBank(BaseAdvice order) : base(order)
    {

    }

    public override string AddAdvice()
    {

        Console.WriteLine("Ha agregado PowerBank");

        var Addition = base.AddAdvice();
        
        return Addition;

    }
}
}