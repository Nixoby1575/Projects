using System;

namespace Aporte2 {
public class Decorator : BaseAdvice
{
    protected BaseAdvice order;
    public Decorator (BaseAdvice order)
    {
        this.order = order;
    }
    public override string AddAdvice()
    {
        return order.AddAdvice();
    }

    public override string Repair()
    {
        return order.Repair();
    }
}
}