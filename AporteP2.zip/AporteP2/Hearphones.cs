using System;

namespace Aporte2 {
public class Hearphones : Decorator
{
    public Hearphones(BaseAdvice order) : base(order)
    {
        
    }

    public override string AddAdvice()
    {
        Console.WriteLine("Ha agregado auriculares");
        var Addition = base.AddAdvice();
        
        return Addition;
    }
}
}