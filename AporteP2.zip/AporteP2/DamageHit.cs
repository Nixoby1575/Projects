namespace Aporte2
{
    public class DamageHit: Decorator{

    public DamageHit(BaseAdvice baseAdvice):base(baseAdvice){

    }
    
    public override string Repair()
    
    {
        var repairing = "Daño seleccionado de dispositivo por golpe";
          return repairing;

    }

    
}

}