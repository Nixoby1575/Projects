using System;
namespace Aporte2
{
    public class Cell : Advices
    {
        public Cell(int IMEI, string Brand, string Model, string OperativeSystem, string Manufacturing, string FunctionAvc_1, string FuctionAvc_2, string FuctionAvc_3) : base(IMEI, Brand, Model, OperativeSystem, Manufacturing, FunctionAvc_1, FuctionAvc_2, FuctionAvc_3) { }

        public override void Print()
        {
            Console.WriteLine("************************");
            Console.WriteLine("Dispositivo a reparar:");
            Console.WriteLine("************************");
            Console.WriteLine("marca: {0}", Brand);
            Console.WriteLine("modelo: {0}", Model);
            Console.WriteLine("imei: {0}", IMEI);
            Console.WriteLine("sistema operativo: {0}", OperativeSystem);
            Console.WriteLine("************************");
        }

        public override void FunctionsAvc()
        {
            Console.WriteLine("************************");
            Console.WriteLine("Funcionalidades: ");
            Console.WriteLine("1. {0}", FunctionAvc_1);
            Console.WriteLine("2. {0}", FuctionAvc_2);
            Console.WriteLine("3. {0}", FuctionAvc_3);
        }
    }
}