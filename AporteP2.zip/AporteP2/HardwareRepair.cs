using System;

namespace Aporte2
{
    public class HardwareRepair: Decorator{

    public HardwareRepair(BaseAdvice baseAdvice):base(baseAdvice){

    }
    public override string Repair(){

        var repacion = "Haz seleccionado reparación de hardware";
          return repacion;

    }
}
}